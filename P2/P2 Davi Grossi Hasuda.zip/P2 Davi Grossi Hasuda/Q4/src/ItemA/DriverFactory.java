package ItemA;

/*
 * ITEM A
 * Implementa o I/O: fornece uma interface/objeto de algo que existe externamente.
 * Antes era a classe SistemaOperacional
 */
public class DriverFactory {
	public Impressora getDriverImpressao() {
		return new Impressora();
	}
}
