package ItemA;

import java.util.Iterator;

/*
 * ITEM A
 * Calcula o total de despesas dado uma lista de despesas
 * */
public class Calculadora {
	
	public float totalDespesas(Iterator<Despesa> despesas) {
		float totalDespesa = 0.0f;
		while (despesas.hasNext()) {
			Despesa desp = despesas.next();
			float despesa = desp.getDespesa();
			totalDespesa+= despesa;
		}
		return totalDespesa;
	}
}
