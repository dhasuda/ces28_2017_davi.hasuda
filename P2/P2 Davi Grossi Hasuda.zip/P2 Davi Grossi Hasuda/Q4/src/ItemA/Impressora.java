package ItemA;

/*
 * ITEM A
 * Imprime algum conteúdo
 */
public class Impressora {
	public void Imprimir(String conteudo) {
		if (conteudo==null) {
			throw new IllegalArgumentException("conteudo nulo");
		}
		else 
			System.out.println(conteudo);
	}
}
