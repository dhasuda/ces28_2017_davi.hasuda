package ItemA;

/*
 * ITEM A
 * Retorna um relatório das despesas
 */
public class RelatorioDespesas {
	
	public String getRelatorio(float totalDespesa) {
		String conteudo = "Relatorio de Despesas";
		conteudo+=("\n Total das despesas:" + totalDespesa);

		return conteudo;
	}
	
}