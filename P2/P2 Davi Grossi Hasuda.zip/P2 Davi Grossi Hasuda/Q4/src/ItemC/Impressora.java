package ItemC;

/*
 * ITEM C
 * Imprime algum conteúdo
 */
public interface Impressora {
	public void Imprimir(String conteudo);
}
