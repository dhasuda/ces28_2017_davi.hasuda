package ItemC;

/*
 * ITEM C
 * Implementa o I/O: fornece uma interface/objeto de algo que existe externamente.
 * Antes era a classe SistemaOperacional
 */
public class DriverFactory {
	private boolean isLaserPrinter = true;
	
	public Impressora getDriverImpressao() {
		if (isLaserPrinter) {
			return new ImpressoraLaser();
		}
		return new ImpressoraTinta();
	}
	
	// É necessário algum método para se trocar a impressora
	public void setImpressoraTinta() {
		isLaserPrinter = false;
	}
	public void setImpressoraLaser() {
		isLaserPrinter = true;
	}
}
