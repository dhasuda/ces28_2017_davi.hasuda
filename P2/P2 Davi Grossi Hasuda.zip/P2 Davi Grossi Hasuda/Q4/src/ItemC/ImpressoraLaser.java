package ItemC;

public class ImpressoraLaser implements Impressora {

	@Override
	public void Imprimir(String conteudo) {
		if (conteudo==null) {
			throw new IllegalArgumentException("conteudo nulo");
		}
		else 
			System.out.println(conteudo);
	}
	
}
