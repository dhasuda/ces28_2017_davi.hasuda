package ItemC;

/*
 * ITEM C
 * Retorna um relatório das despesas
 */
public class RelatorioDespesas {
	
	public String getRelatorio(float totalDespesa) {
		String conteudo = "Relatorio de Despesas";
		conteudo+=("\n Total das despesas:" + totalDespesa);

		return conteudo;
	}
	
}