package ItemC;

import static org.junit.Assert.*;
import java.util.*;

import org.junit.Before;
import org.junit.Test;

import ItemC.Calculadora;
import ItemC.Despesa;
import ItemC.RelatorioDespesas;

public class ItemC {
/*
 * Não sabia se era para fazer um teste para a classe
 * RelatorioDespesas antiga ou a refatorada no item A,
 * e por causa disso fiz testes para ambas separadamente.
 */
	RelatorioDespesas relatorio;
	@Before
	public void setUp() {
		relatorio = new RelatorioDespesas();
	}
	
	/*
	 * Testes da classe RelatorioDespesas já refatorada
	 */
	@Test
	public void testRelatorioDespesasRefatorado() {
		String answer = relatorio.getRelatorio(19.0f);
		assertEquals(answer, "Relatorio de Despesas\n Total das despesas:19.0");
	}
	
	/*
	 * Testes da classe RelatorioDespesas antiga, isto é, 
	 * teste das funções utilizadas em public void ImprimirRelatorio(Iterator<Despesa> despesas) 
	 */
	@Test
	public void testRelatorioDespesasAntigo() {
		// Primeiro testa-se Calculadora.totalDespesas que realiza a soma antes realizada por RelatorioDespesas
		Calculadora calculadora = new Calculadora();
		Set<Despesa> despesas = new HashSet<Despesa>();
		despesas.add(new Despesa(1.0f));
		despesas.add(new Despesa(3.0f));
		despesas.add(new Despesa(10.0f));
		float total = calculadora.totalDespesas(despesas.iterator());
		
		// Teste da impressão do resultdo
		String answer = relatorio.getRelatorio(total);
		assertEquals(answer, "Relatorio de Despesas\n Total das despesas:14.0");

		// Segundo teste por segurança
		despesas.add(new Despesa(50.0f));
		total = calculadora.totalDespesas(despesas.iterator());
		answer = relatorio.getRelatorio(total);
		assertEquals(answer, "Relatorio de Despesas\n Total das despesas:64.0");
	}

}
