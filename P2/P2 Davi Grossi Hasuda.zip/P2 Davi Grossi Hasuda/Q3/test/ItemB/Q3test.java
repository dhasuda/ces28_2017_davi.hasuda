package ItemB;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.Before;
import org.junit.Test;

import ItemB.Alarm;
import ItemB.ISensor;

public class Q3test {

	ISensor sensor;
	Alarm alarm;
	
	@Before
	public void setUp() {
		sensor = mock(ISensor.class);
		alarm = new Alarm(sensor);
	}
	
	@Test
	public void testAlarmCreation() {
		assertNotNull(alarm);
	}
	
	@Test
	public void testAlarmOff() {
		when(sensor.popNextPressurePsiValue()).thenReturn(19.0);
		alarm.check();
		assertFalse(alarm.isAlarmOn());
	}
	
	@Test
	public void testAlarmOn() {
		when(sensor.popNextPressurePsiValue()).thenReturn(0.0);
		alarm.check();
		assertTrue(alarm.isAlarmOn());
	}
	
}
