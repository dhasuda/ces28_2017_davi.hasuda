package Q3testV2;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.Before;
import org.junit.Test;

import Q3V2.Alarm;
import Q3V2.ISensor;

public class Q3test {

	ISensor sensor;
	Alarm alarm;
	
	@Before
	public void setUp() {
		sensor = mock(ISensor.class);
		alarm = new Alarm(sensor);
	}
	
	@Test
	public void testAlarmCreation() {
		assertNotNull(alarm);
	}
	
	@Test
	public void testAlarmOff() {
		when(sensor.popNextPressurePsiValue()).thenReturn(19.0);
		assertFalse(alarm.isAlarmOn());
	}
	
	@Test
	public void testAlarmOn() {
		when(sensor.popNextPressurePsiValue()).thenReturn(0.0);
		assertTrue(alarm.isAlarmOn());
	}
	
}
