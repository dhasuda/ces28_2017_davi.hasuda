package ItemB;

public interface ISensor {
	public double popNextPressurePsiValue();
	double samplePressure();
}
