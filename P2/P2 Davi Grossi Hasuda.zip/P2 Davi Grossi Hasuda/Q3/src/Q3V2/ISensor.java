package Q3V2;

public interface ISensor {
	public double popNextPressurePsiValue();
	double samplePressure();
}
