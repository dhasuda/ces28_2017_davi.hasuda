package Q3V2;



public class Alarm {
	private final double LowPressureThreshold = 17;
    private final double HighPressureThreshold = 21;

    private ISensor sensor;

    private boolean alarmOn = false;
    
    public Alarm(ISensor sensor) {
    		this.sensor = sensor;
    }

    private void check()
    {
        double psiPressureValue = sensor.popNextPressurePsiValue();

        if (psiPressureValue < LowPressureThreshold || HighPressureThreshold < psiPressureValue)
        {
            alarmOn = true;
        }
    }

    public boolean isAlarmOn()
    {
    		this.check();
        return alarmOn; 
    }
}
