package DrinkPackage;

class Ingredient6 extends Ingredient {
	public Ingredient6() {
		this._price = 85;
	}
}
