package DrinkPackage;

public interface Drink {
	public int getPrice();
	public boolean isLimited();
	public boolean hasStudentDiscount();
}
