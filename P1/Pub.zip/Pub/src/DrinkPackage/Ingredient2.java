package DrinkPackage;

class Ingredient2 extends Ingredient {
	public Ingredient2() {
		this._price = 10;
	}
}
