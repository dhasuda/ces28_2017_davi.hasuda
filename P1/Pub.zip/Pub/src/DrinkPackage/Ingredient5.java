package DrinkPackage;

class Ingredient5 extends Ingredient {
	public Ingredient5() {
		this._price = 20;
	}
}
