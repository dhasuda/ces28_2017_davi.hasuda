package DrinkPackage;

class Ingredient1 extends Ingredient {
	public Ingredient1() {
		this._price = 65;
	}
}
