package Q4;

public interface Datacenter {
	public void gerarRelatorio(String msg);
}
