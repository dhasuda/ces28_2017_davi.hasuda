package Q4;

public interface PainelCondutor {
	public boolean imprimeAviso(String msg, int prioridade);
	public void diminuiVelocidadeTrem(double valor);
	public void aceleraVelocidadeTrem(double valor);
}
