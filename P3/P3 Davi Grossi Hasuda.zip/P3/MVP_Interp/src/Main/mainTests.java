package Main;

import java.io.File;
import java.util.HashSet;
import java.util.Observer;

import InterpV0.InterpolationMethod;
import Presenter.Presenter;
import View.IView;
import View.View1;

public class mainTests {
	
	
	/*
	 * NOTAS SOBRE A APLICAÇÃO:
	 * 1) O conceito de camadas é seguido estritamente: veja-se separação de packagem Model, View, Presenter e 
	 * como é realizado o acoplamento entre eles: Model <=> Presenter <=> View
	 * 
	 *  2) Para se acrescentar uma nova view basta criar a nova classe implementando os métodos IView e Observer
	 *  E no momento em que se instancia a nova view deve-se fazer com que ela passe a observar a classe presenter.
	 *  
	 *  3) Para se adicionar outros algoritmos de interpolação basta passá-los como itens do HashSet na construção do presenter
	 *  Dessa forma o presenter já saberá quais são os métodos disponíveis para ele realizar a interpolação e utilizá-los torna-se 
	 *  muito mais fácil, bastando apenas chamas o método setMethod(String method) com o nome do método desejado.
	 */
	
	public static void main(String[] args) {
		HashSet<InterpolationMethod> mSet = new HashSet<InterpolationMethod>();
		Presenter presenter = new Presenter(mSet);
		View1 view = new View1(presenter);
		presenter.addObserver(view);
		view.setMethod("Lagrange");
		view.setValues(10.3f, new File("./data.dat"));
	}
}
