package View;

import java.util.Observable;
import java.util.Observer;
import java.io.File;
import java.text.DecimalFormat;

import Presenter.Presenter;

public class View1 implements IView, Observer {
	
    
    private File _file;
    private double _value;
    private double result;
	private Presenter presenter;
	private DecimalFormat formatResult = new DecimalFormat("####.######");
	
	public View1(Presenter presenter) {
		this.presenter = presenter;
	}
	
	@Override
	public void setValues(float value, File file) {
		_file = file;
		_value = value;
		presenter.setValues(value, file);
	}
	
	@Override
	public void setMethod(String method) {
		presenter.setMethod(method);
	}

	// RESPONSABILITY: IMPRIMIR RESULTADOS
	@Override
	public void printResult() {
		System.out.println("***********************");
	    	System.out.println("DataFile: " + _file);
	    	System.out.println("Interp at " + formatResult.format(_value) + " ; result = " + formatResult.format(result));
	}
	
	/*
	 * Observer methods
	 */
	@Override
	public void update(Observable o, Object arg) {
		result = presenter.getResult();
		this.printResult();
	}

}
