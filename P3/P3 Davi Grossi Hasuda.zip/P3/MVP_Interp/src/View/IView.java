package View;

import java.io.File;

public interface IView {
	void setValues(float value, File file);
	void setMethod(String method);
	//RESPONSABILITY: IMPRIMIR RESULTADOS
	void printResult();
}
