package Presenter;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.Observable;
import java.util.StringTokenizer;
import java.util.Vector;

import InterpV0.CubicSpline;
import InterpV0.InterpolationMethod;
import InterpV0.Lagrange;

public class Presenter extends Observable {
	
	private FileReader input;
    private BufferedReader bufRead;
    private StringTokenizer xy;
    private Vector<Double> x, y;
	private InterpolationMethod interpolationModel;
    private double _value, result;
    private File _file;
    private String resultTxt = "";
    private boolean validResult = false;
    private HashSet<InterpolationMethod> methodsSet;
	
    
	public Presenter(HashSet<InterpolationMethod> methodsSet) {
		this.methodsSet = methodsSet;
		if (methodsSet.isEmpty()) {
			this.methodsSet.add(new Lagrange());
			this.methodsSet.add(new CubicSpline());
		}
		boolean hasLagrange = false;
		boolean hasCubic = false;
		for(InterpolationMethod m : this.methodsSet) {
			if (m instanceof Lagrange) {
				hasLagrange = true;
			} else if (m instanceof CubicSpline) {
				hasCubic = true;
				this.interpolationModel = m;
			}
		}
		if (!hasLagrange) {
			this.methodsSet.add(new Lagrange());
		}
		if (!hasCubic) {
			InterpolationMethod m = new CubicSpline();
			interpolationModel = m;
			this.methodsSet.add(m);
		}
	}
	
	public File getDataFile() {    
        return _file;
    }
	
	//RESPONSABILITY: ESCOLHER O METODO DE INTERPOLACAO DESEJADO E CRIAR O OBJETO CORRESPONDENTE
	public InterpolationMethod getMethod() { return interpolationModel; }
	
	public InterpolationMethod setMethod(String method) {
		for (InterpolationMethod m : methodsSet) {
			if (m.toString().equals(method)) {
				interpolationModel = m;
			}
		}
        return interpolationModel;
    }
	
	
	// CHAMAR A FUNÇÃO DE CÁLCULO QUANDO FOREM SETTADOS OS PARÂMETROS
	public void setValues(float value, File file) {
		buildDataPoints(file);
		this.calculateResult(value);
	}
	
    // RESPONSABILITY: DADO O VALOR DE X, CALCULAR.
    private void calculateResult(float value) {
        _value = value;
        if(getMethod() != null) {
            result = getMethod().calculateResult(_value, x, y);
            this.validResult = true;
        } else {
        		this.validResult = false;
            System.out.println("It is not defined an interpolation method.");
        }
        super.setChanged();
        super.notifyObservers();
    }
    
 // RESPONSABILITY: LER ARQUIVO DE DADOS
 	private void buildDataPoints(File file) {
         if(file == null)
            return;
         else _file = file;

         x = new Vector<Double>();
         y = new Vector<Double>();
         try {
             input = new FileReader(_file);
 		    /* Filter FileReader through a Buffered read to read a line at a time */
             bufRead = new BufferedReader(input);
             // Read first line
             String line = bufRead.readLine();
             // Read through file one line at time.
             while (line != null){
                 xy = new StringTokenizer(line, "\t ");
                 while(xy.hasMoreTokens()) {
                     x.addElement(Double.parseDouble(xy.nextToken()));
                     y.addElement(Double.parseDouble(xy.nextToken()));
                 }
                 line = bufRead.readLine();
             }
             bufRead.close();
         } catch (IOException e) { // If another exception is generated, print a stack trace
             e.printStackTrace();
         }
     }//buildDataPoints
    
    // RESPONSABILITY: RETORNAR TEXTO COM RESULTADOS
    public String getResultText() {
    		return this.resultTxt;
    }
    
    public boolean isResultValid() {
    		return this.validResult;
    }
    
    public double getResult() {
    		return this.result;
    }
    

	
    

	
}
