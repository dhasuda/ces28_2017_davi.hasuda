package Aula11ObserverEx11;

public class TelaConversa extends Observer {
	private Usuario user;
	
	public TelaConversa(Usuario u) {
		this.user = u;
	}
	
	@Override
	public void update() {
		int value = user.getValue();
		System.out.println(value);
	}
	

}
