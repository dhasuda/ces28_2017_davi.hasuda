package Aula11ObserverEx12;

import java.util.Observable;
import java.util.Observer;

public class TelaConversa implements Observer {

	@Override
	public void update(Observable o, Object arg) {
		int value = ((Usuario) o).getValue();
		System.out.println(value);
	}
	

}
