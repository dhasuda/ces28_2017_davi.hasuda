package Aula11ObserverEx12;

import java.util.Observable;

public class Usuario extends Observable {
	private int value = 0;
	
	public int getValue() {
		return this.value;
	}
	
	public void setValue(int v) {
		this.value = v;
		super.setChanged();
		super.notifyObservers();
	}
	
}
