package Aula11ObserverEx12;

public class SistemaCliente {
	
	
	
	public static void main(String [] args) {
		Usuario user; 
		
		user = new Usuario();
		Observadores obs1 = new Observadores("Obs1", user);
		user.addObserver(obs1);
		Observadores obs2 = new Observadores("Obs2", user);
		user.addObserver(obs2);
		
		user.setValue(19);
		user.deleteObserver(obs2);
		user.setValue(100);
		
	}

}
