package Aula11ObserverEx12;
import java.util.Observable;
import java.util.Observer;

public class Observadores implements Observer{

	private String name;
	
	public Observadores (String name, Usuario user) {
		this.name = name;
	}
	
	
	public String getName() {
		return name;
	}

	@Override
	public void update(Observable o, Object arg) {
		
		int value = ((Usuario) o).getValue();
		System.out.println(this.name + " notificado: value = " + value);
	}
}
