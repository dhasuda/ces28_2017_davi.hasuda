package Aula11ObserverEx11;

import java.util.HashSet;
import java.util.Set;

public abstract class Subject {
	Set<Observer> observers = new HashSet<Observer>();
	
	public void attach(Observer o) {
		observers.add(o);
	}
	public void dettach(Observer o) {
		observers.remove(o);
	}
	
	protected void notificar() {
		for (Observer o : observers) {
			o.update();
		}
	}
	
}
