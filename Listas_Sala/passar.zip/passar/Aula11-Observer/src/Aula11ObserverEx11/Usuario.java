package Aula11ObserverEx11;

public class Usuario extends Subject {
	private int value = 0;
	
	public int getValue() {
		return this.value;
	}
	
	public void setValue(int v) {
		this.value = v;
		super.notificar();
	}
	
}
