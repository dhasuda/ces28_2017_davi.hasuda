package Aula11ObserverEx11;

public class Observadores extends Observer{

	private String name;
	private Usuario user;
	
	public Observadores (String name, Usuario user) {
		this.name = name;
		this.user = user;
		
	}
	
	@Override
	public void update() {
		int value = user.getValue();
		//System.out.println(value);
		System.out.println(this.name + " notificado: value = " + value);
	}
	
	public String getName() {
		return name;
	}
}
