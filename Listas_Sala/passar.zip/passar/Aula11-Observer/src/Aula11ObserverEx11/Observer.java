package Aula11ObserverEx11;

public abstract class Observer {
	public abstract void update();
}
