package Aula11ObserverEx11;

public class SistemaCliente {
	
	
	
	public static void main(String [] args) {
		Usuario user;
		/*TelaConversa tela;
		
		
		user = new Usuario();
		tela = new TelaConversa(user);
		user.attach(tela);
		
		user.setValue(19);
		user.setValue(100);
		user.setValue(82347);
		*/
		
		user = new Usuario();
		Observadores obs1 = new Observadores("Obs1", user);
		user.attach(obs1);
		Observadores obs2 = new Observadores("Obs2", user);
		user.attach(obs2);
		
		user.setValue(19);
		user.dettach(obs2);
		user.setValue(100);
		
	}

}
