package Aula11ObserverEx17;


import java.util.Observable;
import java.util.Observer;

public class PublishSubscriber extends Observable implements Observer {

	private int numEditionPublisher;
	
	@Override
	public void update(Observable o, Object arg) {
		numEditionPublisher = ((Publisher) o).getNumEdition();
		setNumEditionPublisher((Publisher) o);
	}
	
	public void setNumEditionPublisher(Publisher publisher){
		this.numEditionPublisher = publisher.getNumEdition();
		super.setChanged();
		super.notifyObservers();
	}
	
	public String getNumEditionPublisher() {
		return "New edition available! Check right now n.o " + this.numEditionPublisher + "!";
	}

}
