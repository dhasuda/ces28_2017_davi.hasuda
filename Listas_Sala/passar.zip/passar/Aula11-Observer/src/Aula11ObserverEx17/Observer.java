package Aula11ObserverEx17;

public class Observer {

}
