package Aula11ObserverEx17;

import java.util.Observable;
import java.util.Observer;

public class Exercicio17 {
	public static void main(String [] args) {
		PublishSubscriber PB = new PublishSubscriber();
		Publisher subject1 = new Publisher();
		Publisher subject2 = new Publisher();
		Subscriber observer1 = new Subscriber();
		Subscriber observer2 = new Subscriber(); 

		subject1.addObserver(PB);
		subject2.addObserver(PB);
		PB.addObserver(observer1);
		PB.addObserver(observer2);
		
		
		subject1.setNumEdition(10);
		subject2.setNumEdition(150);
		subject1.setNumEdition(15);
		subject1.deleteObserver(PB);
		subject2.deleteObserver(PB);
		

	}
	
}
