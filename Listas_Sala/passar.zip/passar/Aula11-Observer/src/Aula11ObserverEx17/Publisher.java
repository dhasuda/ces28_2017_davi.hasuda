package Aula11ObserverEx17;


import java.util.Observable;


public class Publisher extends Observable {
	
	private int numEdition;
	
	//private Set publishSubscriber = new HashSet<PublishSubscriber>();
	
	public int getNumEdition() {
		return this.numEdition;
	}
	
	public void setNumEdition(int numEdition) {
		this.numEdition = numEdition;
		super.setChanged();
		super.notifyObservers();
	}
	
}
