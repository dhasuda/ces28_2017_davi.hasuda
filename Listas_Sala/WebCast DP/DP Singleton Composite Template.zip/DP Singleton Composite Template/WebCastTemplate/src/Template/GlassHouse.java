package Template;

public class GlassHouse extends House {

	@Override
	protected void buildPillars() {
	
	  System.out.println("Building Glass with Wood coating");
	}
	
	@Override
	protected void buildWalls() {
	  System.out.println("Building Glass Walls");
	}
}
