package Template;

public class WoodenHouse extends House  {

	@Override
	protected void buildPillars() {
	
	  System.out.println("Building Pillars with Wood coating");
	}
	
	@Override
	protected void buildWalls() {
	  System.out.println("Building Wooden Walls");
	}

}
