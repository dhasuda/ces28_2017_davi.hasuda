package Singleton;

import java.util.*;
import java.util.concurrent.TimeUnit;

public class Application {
	String msg;
	
	// Cria dois objetos do Application
	private static List<Application> objects = new ArrayList<Application>();
	
	private static int counter = 0;

	private Application(String msg){
		this.msg = msg;
		try {
			System.out.println("waiting 3 seconds");
			TimeUnit.SECONDS.sleep(3);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
		   
	public static synchronized Application getInstance() throws IllegalAccessException{
		if (objects.size() < 2) {
			objects.add(new Application("first"));
			objects.add(new Application("second"));
		}
		if (counter >= 3) {
			throw new IllegalAccessException();
		}
		if (counter == 2 && objects.size() < 3) {
			objects.add(new Application("third"));
		}
		counter ++;
		return objects.get(counter-1);
	}
	
	public static void decrement() {
		if(counter >= 1) {
			counter--;
		}
	}
	
	public void getMessage() {
		System.out.println(this.msg);
	}
	
}
