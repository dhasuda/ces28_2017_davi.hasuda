package Singleton;

import java.util.concurrent.TimeUnit;

public class Singleton {
	private static Singleton _theApplication = null;
	private static Boolean instanceFlag = false;
	

	private Singleton() {
		try {
			TimeUnit.SECONDS.sleep(3);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public static synchronized Singleton getApplication() {
		if (! instanceFlag) {
			return create();
		} else {
		return _theApplication;
		}
	}
	
	private static Singleton create() {
		System.out.println("Creating new singleton");
		_theApplication = new Singleton();
		instanceFlag = true;
		return _theApplication;
	}
	
}
