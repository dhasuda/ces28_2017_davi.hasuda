package Singleton;

import java.util.concurrent.TimeUnit;

import Singleton.Application;

public class Main {

	public static void main(String[] args) throws IllegalAccessException {
		System.out.println("Getting one applications and decreenting");
		Application ap1 = Application.getInstance();
		Application.decrement();
		
		System.out.println("Getting two applications");
		ap1 = Application.getInstance();
		Application ap2 = Application.getInstance();
		
		System.out.println("Getting third application");
		Application ap3 = Application.getInstance();
		
		System.out.println("Trying to get fourth element");
		Application ap4 = null;
		try {
			ap4 = Application.getInstance();
		} catch (IllegalAccessException e) {
			System.out.println("IllegalAccessException");
		}
		
		System.out.println("Decrementing one element");
		ap3 = null;
		Application.decrement();
		
		System.out.println("Getting third application");
		ap3 = Application.getInstance();
		Application.decrement();
		Application.decrement();
		Application.decrement();
		
		System.out.println("");
		System.out.println("Threads test: (Must create only one new singleton)");
		
		MyThread t1 = new MyThread();
		MyThread t2 = new MyThread();
		t1.start();
		t2.start();
		try {
			TimeUnit.SECONDS.sleep(5);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		if (t1.getSingleton() == t2.getSingleton()) {
			System.out.println("They are equal!");
		}
		
	}
}