package Singleton;

import Singleton.Application;
import Singleton.Singleton;

public class MyThread extends Thread {
	
	Singleton sin = null;
	
	@Override
	public void run() {
		/*Application ap = null;
		try {
			ap = Application.getInstance();
		} catch (IllegalAccessException e) {
			System.out.println("IllegalAccessException");
		}
		System.out.println("Getting application");
		if (ap != null) {
			System.out.println(ap.msg);
		}*/
		sin = Singleton.getApplication();
		System.out.println("Got singleton");
	}
	
	public Singleton getSingleton() {
		return sin;
	}
}
