package Composite;

import java.util.ArrayList;
import java.util.List;

public class Drawing implements Shape {
	List<Shape> shapes = new ArrayList<Shape>();
	
	@Override
	public void draw(String fillColor) {
		for (Shape s : shapes) {
			s.draw(fillColor);
		}
	}

	public void add(Shape shape) {
		shapes.add(shape);
	}
	
	public void remove(Shape shape) {
		shapes.remove(shape);
	}
	
	public void clear() {
		shapes.clear();
		System.out.println("Clearing all the shapes from drawing");
	}
	
}
