package Application;

//import mercadoVirtual.BancoDeDados;
//import mercadoVirtual.Carrinho;
//import mercadoVirtual.Cliente;
//import mercadoVirtual.Produto;
import mercadoVirtual.Facade;

public class Aplicacao {
	public static void main(String[] args) {
		Facade facade = new Facade();
		facade.setCliente("ZÈ", 123);
		facade.comprar(223);
		facade.comprar(342);
		facade.fecharCompra();
	}
}

