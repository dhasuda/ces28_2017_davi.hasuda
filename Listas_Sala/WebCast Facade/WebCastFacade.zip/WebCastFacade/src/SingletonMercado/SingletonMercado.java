package SingletonMercado;

public class SingletonMercado {
	static Mercado mercado = null;
	public static Mercado getMercado() {
		if (mercado == null) {
			mercado = new Mercado();
		}
		return mercado;
	}
}
