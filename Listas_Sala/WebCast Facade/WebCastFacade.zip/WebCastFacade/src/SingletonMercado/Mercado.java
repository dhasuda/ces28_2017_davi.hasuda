package SingletonMercado;

import Singleton.BancoDeDados;
import Singleton.SingletonBD;
import mercadoVirtual.Carrinho;
import mercadoVirtual.Cliente;
import mercadoVirtual.Produto;

public class Mercado {
	private BancoDeDados banco;
	private Cliente cliente;
	
	Mercado() {
		banco = SingletonBD.getBancoDeDados();
	}
	
	public void setCliente(String nome, int id) {
		cliente = Cliente.create(nome, id);
		Carrinho car = Carrinho.create();
		cliente.setCarrinho(car);
		banco.registrarCliente(cliente);
	}
	
	public void comprar(int productId) {
		Produto produto = banco.selectProduto(productId);
		cliente.adicionarProduto(produto);
	}
	
	public void fecharCompra() {
		double valor = cliente.getTotal();
		banco.processarPagamento(cliente, valor);
	}
}
