package mercadoVirtual;

public class Cliente {
	private int id;
	private String nome;
	private Carrinho carrinho;
	private Cliente(String nome, int id) {
		this.id = id;
		this.nome = nome;
	}
	public static Cliente create(String nome, int id) {
		return new Cliente(nome, id);
	}
	public void setCarrinho(Carrinho c) {
		this.carrinho = c;
	}
	public Carrinho getCarrinho() {
		return carrinho;
	}
	
	public void adicionarProduto(Produto produto) {
		carrinho.adicionar(produto);
	}
	
	public double getTotal() {
		return carrinho.getTotal();
	}
	
	public int getId() {
		return id;
	}
}

