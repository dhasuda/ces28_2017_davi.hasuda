package mercadoVirtual;

import SingletonMercado.Mercado;
import SingletonMercado.SingletonMercado;

public class Facade {
	Mercado mercado;
	
	public Facade() {
		mercado = SingletonMercado.getMercado();
	}
	
	public void setCliente(String nome, int id) {
		mercado.setCliente(nome, id);
	}
	
	public void comprar(int productId) {
		mercado.comprar(productId);
	}
	
	public void fecharCompra() {
		mercado.fecharCompra();
	}
}
