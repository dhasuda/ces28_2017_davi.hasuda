package Singleton;

import mercadoVirtual.Carrinho;
import mercadoVirtual.Cliente;

public class SingletonBD {
	private static BancoDeDados banco = null;
	private static Cliente cliente = null;
	private static Carrinho carrinho = null;
	
	public static BancoDeDados getBancoDeDados() {
		if (banco == null) {
			banco = new BancoDeDados();
		}
		return banco;
	}
	
}
