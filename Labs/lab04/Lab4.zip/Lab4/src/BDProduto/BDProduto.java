package BDProduto;

public interface BDProduto {
	public Compravel getCompravel(String nome) throws NullPointerException;
}
