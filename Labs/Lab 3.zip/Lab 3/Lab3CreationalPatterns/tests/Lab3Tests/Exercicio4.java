package Lab3Tests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import Lab3.Address;
import Lab3.Date;
import Lab3.Letter;
import Lab3.LetterBuilder;
import Lab3.Person;

public class Exercicio4 {

	private String language;
	private String model;
	private Person sender;
	private Person destinatary;
	private Address addressSender;
	private Address addressDestiny;
	private Date date;
	
	@Before
	public void setUp() {
		sender = new Person("Sender", "sender@servidor", "0000-0000");
		destinatary = new Person("Destinary", "destinary@servidor", "1111-1111");
		addressSender = new Address("sender add");
		addressDestiny = new Address("destiny add");
		date = new Date(2017, 10, 10);
	}
	
	@Test
	public void changeLanguageModel() {
		language = "Portuguese";
		model = "I";
		Letter letter = LetterBuilder.getCommercialLetter(sender, destinatary, addressSender, addressDestiny, date, language, model);
		String expectedText = "10/10/2017\n" + 
				"\n" + 
				"Sr. Sender\n" + 
				"Rua sender add\n" + 
				"Sr. DestinaryRua destiny add\n" + 
				"Dear   Sr. Destinary\n" + 
				"\n" + 
				"Sincerely,\n" + 
				"\n" + 
				"\n" + 
				"__________________\n" + 
				" +55 0000-0000Sr. Sender\n" + 
				"\n" + 
				"                                    email:sender@servidor";
		assertEquals(letter.getText(), expectedText);
		
		model = "II";
		letter = LetterBuilder.getCommercialLetter(sender, destinatary, addressSender, addressDestiny, date, language, model);
		expectedText = "10/10/2017\n" + 
				"\n" + 
				"Sr. Sender\n" + 
				"Rua sender add\n" + 
				"Sr. DestinaryRua destiny add\n" + 
				"Dear   Sr. Destinary\n" + 
				"\n" + 
				"Sincerely,\n" + 
				"\n" + 
				"\n" + 
				"__________________\n" + 
				" DDI: +55 Tel: 0000-0000Sr. Sender\n" + 
				"\n" + 
				"                                    email:sender@servidor";
		assertEquals(letter.getText(), expectedText);
	}


}
