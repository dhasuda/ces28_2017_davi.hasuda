package Lab3Tests;

import static org.junit.Assert.*;

import org.junit.Test;

public class Exercicio5 {

	/*
	 * Mesmos testes do Exercicio3.java são válidos, necessários e suficientes aqui.
	 */
	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
