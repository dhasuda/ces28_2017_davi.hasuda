package Lab3;


public class CommercialSignature extends Paragraph {

	@Override
	public String getString() {
		return "\n\n__________________\n " + sender.getDecoratedPhone() +
				 sender.getDecoratedName() + "\n" +
				 "\n                                    email:"   +   sender.getEmail();
	}

}
