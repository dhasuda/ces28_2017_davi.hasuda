package Lab3;

public class LetterBuilder {
	
	private static void changeLanguage(String language, Person sender, Person destinatary, Address addressSender, Address addressDestiny, String model) {
		if (language != "") {
			LanguageAbstractFactory languageFactorySender = LanguageFactory.getFactory(sender, addressSender, language);
			languageFactorySender.setPersonDecorated(sender, addressSender, model);
			LanguageAbstractFactory languageFactoryDestinatary = LanguageFactory.getFactory(destinatary, addressDestiny, language);
			languageFactoryDestinatary.setPersonDecorated(destinatary, addressDestiny, model);
		}
	}
	
	/*
	 * Always the default model is the model I
	 */
	public static Letter getCommercialLetter(Person sender, Person destinatary, Address addressSender, Address addressDestiny, Date date, String language) {
		return getCommercialLetter(sender, destinatary, addressSender, addressDestiny, date, language, "I");
	}
	
	public static Letter getRomanticLetter(Person sender, Person destinatary, Address addressSender, Address addressDestiny, Date date, String language) {
		return getRomanticLetter(sender, destinatary, addressSender, addressDestiny, date, language, "I");
	}
	
	public static Letter getAdvertisingLetter(Person sender, Person destinatary, Address addressSender, Address addressDestiny, Date date, String language) {
		return getAdvertisingLetter(sender, destinatary, addressSender, addressDestiny, date, language, "I");
	}

	public static Letter getCommercialLetter(Person sender, Person destinatary, Address addressSender, Address addressDestiny, Date date, String language, String model) {
		changeLanguage(language, sender, destinatary, addressSender, addressDestiny, model);
		
		Letter letter = new Letter(sender, destinatary, addressSender, addressDestiny, date);
		
		letter.addParagraph(new CommercialHeader());
		letter.addParagraph(new CommercialBody());
		letter.addParagraph(new CommercialConclusion());
		letter.addParagraph(new CommercialSignature());
		
		return letter;
	}
	
	public static Letter getRomanticLetter(Person sender, Person destinatary, Address addressSender, Address addressDestiny, Date date, String language, String model) {
		changeLanguage(language, sender, destinatary, addressSender, addressDestiny, model);
		
		Letter letter = new Letter(sender, destinatary, addressSender, addressDestiny, date);
		
		letter.addParagraph(new LoveHeader());
		letter.addParagraph(new LoveBody());
		letter.addParagraph(new LoveConclusion());
		
		return letter;
	}
	
	public static Letter getAdvertisingLetter(Person sender, Person destinatary, Address addressSender, Address addressDestiny, Date date, String language, String model) {
		changeLanguage(language, sender, destinatary, addressSender, addressDestiny, model);
		
		Letter letter = new Letter(sender, destinatary, addressSender, addressDestiny, date);
		
		letter.addParagraph(new CommercialHeader());
		letter.addParagraph(new CommercialBody());
		letter.addParagraph(new AdvertisingConclusion());
		
		return letter;
	}
	
}
