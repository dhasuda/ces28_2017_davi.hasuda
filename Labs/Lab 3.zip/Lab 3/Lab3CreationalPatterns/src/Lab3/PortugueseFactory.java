package Lab3;

import java.util.HashMap;
import java.util.Map;

public class PortugueseFactory implements LanguageAbstractFactory {
	
	private Map<String, PersonDecorated> _dictionary = new HashMap<String, PersonDecorated>();
	
	private String _name;
	private String _phoneNumber;
	private String _address;
	
	public PortugueseFactory(Person person, Address address) {
		_dictionary.put("I", new PersonDecoratedPortugueseI(person, address));
		_dictionary.put("II", new PersonDecoratedPortugueseII(person, address));
	}
	
	public void setPersonDecorated(Person person, Address address, String model){
		_name = _dictionary.get(model).getName();
		_phoneNumber = _dictionary.get(model).getPhoneNumber();
		_address = _dictionary.get(model).getAddress();
		
		person.setDecoratedName(_name);
		person.setDecoratedPhoneNumber(_phoneNumber);
		address.setDecoratedName(_address);
	}
	
}
