package Lab3;

public class LoveHeader extends Paragraph {

	@Override
	public String getString() {
		return "My darling\n";
	}

}
