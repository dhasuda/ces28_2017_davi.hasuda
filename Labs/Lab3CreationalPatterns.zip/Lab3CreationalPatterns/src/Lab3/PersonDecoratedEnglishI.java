package Lab3;

public class PersonDecoratedEnglishI implements PersonDecorated {
	
	private String _decoratedName;
	private String _decoratedPhoneNumber;
	private String _decoratedAddress;
	
	private String decorateName(String name) {
		return "Mr. " + name;
	}
	
	private String decoratePhoneNumber(String phoneNumber) {
		return "+1 " + phoneNumber;
	}
	
	private String decorateAddress(String address){
		return "St. " + address;
	}
	
	
	public PersonDecoratedEnglishI(Person person, Address address) {
		_decoratedName = decorateName(person.getName());
		_decoratedPhoneNumber = decoratePhoneNumber(person.getPhone());
		_decoratedAddress = decorateAddress(address.getName());
	}
	
	public String getName() {
		return _decoratedName;
	}
	
	public String getAddress() {
		return _decoratedAddress;
	}
	
	public String getPhoneNumber() {
		return _decoratedPhoneNumber;
	}

}
