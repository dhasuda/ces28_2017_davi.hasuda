package Lab3;

public class Person {
	private String name;
	private String phone;
	private String email;
	private String decoratedName;
	private String decoratedPhone;
	
	public Person(String name, String email, String phone) {
		this.name = name;
		this.email = email;
		this.phone = phone;
		
		this.decoratedName = name;
		this.decoratedPhone = phone;
	}
	
	public String getName() {
		return this.name;
	}
	
	public String getPhone() {
		return this.phone;
	}
	
	public String getEmail() {
		return this.email;
	}
	
	public String getDecoratedName() {
		return this.decoratedName;
	}
	
	public String getDecoratedPhone() {
		return this.decoratedPhone;
	}
	
	public void setDecoratedName(String decoratedName) {
		this.decoratedName = decoratedName;
	}

	public void setDecoratedPhoneNumber(String decoratedPhoneNumber) {
		this.decoratedPhone = decoratedPhoneNumber;
	}
	
}
