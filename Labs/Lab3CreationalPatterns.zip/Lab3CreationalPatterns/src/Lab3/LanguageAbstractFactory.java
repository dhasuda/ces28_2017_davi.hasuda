package Lab3;

public interface LanguageAbstractFactory {
	public abstract PersonDecorated getPersonDecorated(Person person, Address address);
}
