package Lab3;
public class LoveConclusion extends Paragraph {

	@Override
	public String getString() {
		return "\n\n                 With all my love\n";
	}
	
}
