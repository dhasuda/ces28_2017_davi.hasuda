package Lab3;

public class LanguageFactory {

	public static LanguageAbstractFactory getFactory(Person person, Address address, String language) {
		if (language.equalsIgnoreCase("English"))
			return new EnglishFactory(person, address);
		if (language.equalsIgnoreCase("Portuguese"))
			return new PortugueseFactory(person, address);
		return null;
	}
		
}
