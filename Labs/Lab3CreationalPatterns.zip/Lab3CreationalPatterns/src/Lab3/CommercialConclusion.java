package Lab3;


public class CommercialConclusion extends Paragraph {

	@Override
	public String getString() {
		return  "\nSincerely,\n";
	}

}
