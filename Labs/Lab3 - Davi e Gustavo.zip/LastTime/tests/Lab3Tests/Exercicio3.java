package Lab3Tests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import Lab3.Address;
import Lab3.Date;
import Lab3.Letter;
import Lab3.LetterBuilder;
import Lab3.Person;

public class Exercicio3 {

	private String language;
	private String model;
	private String structure;
	private Person sender;
	private Person destinatary;
	private Address addressSender;
	private Address addressDestiny;
	private Date date;
	
	@Before
	public void setUp() {
		language = "";
		model = "";
		structure = "";
		sender = new Person("Sender", "sender@servidor", "0000-0000");
		destinatary = new Person("Destinary", "destinary@servidor", "1111-1111");
		addressSender = new Address("sender add");
		addressDestiny = new Address("destiny add");
		date = new Date(2017, 10, 10);
	}
	
	@Test
	public void testEnglish() {
		language = "English";
		Letter letter = LetterBuilder.getCommercialLetter(sender, destinatary, addressSender, addressDestiny, date, language, model, structure);
		String expectedText = "Mr. Sender\n" + 
				"St. sender add\n" + 
				"10/10/2017\n" +
				"\n" + 
				"Mr. Destinary\n" +
				"St. destiny add\n" +
				"\n" +  
				"Dear   Mr. Destinary\n" + 
				"\n" + 
				"Sincerely,\n" +
				"\n\n" +
				"__________________\n" + 
				" +1 0000-0000Mr. Sender\n" + 
				"\n" + 
				"                                    email:sender@servidor";
		assertEquals(letter.getText(), expectedText);
		
		letter = LetterBuilder.getAdvertisingLetter(sender, destinatary, addressSender, addressDestiny, date, language, model, structure);
		expectedText = "Mr. Sender\n" + 
				"St. sender add\n" + 
				"10/10/2017\n" +
				"\n" +
				"Mr. Destinary\n" + 
				"St. destiny add\n" + 
				"\n" +
				"Dear   Mr. Destinary\n" + 
				"             Have a nice week\n";
		assertEquals(letter.getText(), expectedText);
		
		letter = LetterBuilder.getRomanticLetter(sender, destinatary, addressSender, addressDestiny, date, language, model, structure);
		expectedText = "My darling\n" + 
				"I love you \n" + 
				"\n" + 
				"\n" + 
				"                 With all my love\n";
		assertEquals(letter.getText(), expectedText);
	}
	
	@Test
	public void testPortuguese() {
		language = "Portuguese";
		Letter letter = LetterBuilder.getCommercialLetter(sender, destinatary, addressSender, addressDestiny, date, language, model, structure);
		String expectedText = "Rua destiny add, 10/10/2017\n" + 
				"\n" + 
				"Sr. Destinary\n" +
				"\n" +
				"Dear   Sr. Destinary\n" + 
				"\n" + 
				"Atenciosamente\n" + 
				"\n" + 
				"\n" +
				"__________________\n" + 
				" Sr. Sender\n" +
				"+55 0000-0000\n" +
				"email:sender@servidor";
		assertEquals(letter.getText(), expectedText);

		
		letter = LetterBuilder.getAdvertisingLetter(sender, destinatary, addressSender, addressDestiny, date, language, model, structure);
		expectedText = "Rua destiny add, 10/10/2017\n" + 
				"\n" + 
				"Sr. Destinary\n" + 
				"\n" +
				"Dear   Sr. Destinary\n" + 
				"             Tenha uma boa semana\n";
		assertEquals(letter.getText(), expectedText);
		
		letter = LetterBuilder.getRomanticLetter(sender, destinatary, addressSender, addressDestiny, date, language, model, structure);
		expectedText = "Meu querido\n" + 
				"I love you \n" + 
				"\n" + 
				"\n" + 
				"                 Com todo o meu amor\n";
		assertEquals(letter.getText(), expectedText);
	}
	
	@Test
	public void changeLanguage() {
		language = "Portuguese";
		Letter letter = LetterBuilder.getCommercialLetter(sender, destinatary, addressSender, addressDestiny, date, language, model, structure);
		String expectedText = "Rua destiny add, 10/10/2017\n" + 
				"\n" + 
				"Sr. Destinary\n" +
				"\n" +  
				"Dear   Sr. Destinary\n" + 
				"\n" + 
				"Atenciosamente\n" + 
				"\n" + 
				"\n" + 
				"__________________\n" + 
				" Sr. Sender\n" +
				"+55 0000-0000\n" +
				"email:sender@servidor";
		assertEquals(letter.getText(), expectedText);
		
		language = "English";
		letter = LetterBuilder.getCommercialLetter(sender, destinatary, addressSender, addressDestiny, date, language, model, structure);
		expectedText = "Mr. Sender\n" + 
				"St. sender add\n" + 
				"10/10/2017\n" +
				"\n" +
				"Mr. Destinary\n" +
				"St. destiny add\n" +
				"\n" +
				"Dear   Mr. Destinary\n" + 
				"\n" + 
				"Sincerely,\n" + 
				"\n" + 
				"\n" + 
				"__________________\n" + 
				" +1 0000-0000Mr. Sender\n" + 
				"\n" + 
				"                                    email:sender@servidor";
		assertEquals(letter.getText(), expectedText);
		
		letter = LetterBuilder.getAdvertisingLetter(sender, destinatary, addressSender, addressDestiny, date, language, model, structure);
		expectedText = "Mr. Sender\n" + 
				"St. sender add\n" + 
				"10/10/2017\n" +
				"\n" +
				"Mr. Destinary\n" +
				"St. destiny add\n" +
				"\n" +
				"Dear   Mr. Destinary\n" + 
				"             Have a nice week\n";
		assertEquals(letter.getText(), expectedText);
		
		letter = LetterBuilder.getRomanticLetter(sender, destinatary, addressSender, addressDestiny, date, language, model, structure);
		expectedText = "My darling\n" + 
				"I love you \n" + 
				"\n" + 
				"\n" + 
				"                 With all my love\n";
		assertEquals(letter.getText(), expectedText);

	}

}
