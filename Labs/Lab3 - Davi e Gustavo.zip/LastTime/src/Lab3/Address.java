package Lab3;

public class Address {
	private String name;
	private String decoratedName;
	
	public Address(String name) {
		this.name = name;
		this.decoratedName = name;
	}
	
	public String getName() {
		return this.name;
	}
	
	public String getDecoratedName() {
		return this.decoratedName;
	}
	
	public void setDecoratedName(String decoratedAddressName) {
		this.decoratedName = decoratedAddressName;
	}
}
