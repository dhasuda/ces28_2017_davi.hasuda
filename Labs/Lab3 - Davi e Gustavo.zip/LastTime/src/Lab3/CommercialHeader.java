package Lab3;


public class CommercialHeader extends Paragraph {
/*	
	public CommercialHeader(Person sender, Person destinatary, Address addressSender, Address addressDestiny, Date date) {
		//super(sender, destinatary, addressSender, addressDestiny, date);
		super();
	}
*/	
	
	private String _structure;
	
	private String englishHeader() {
		return	sender.getDecoratedName() + "\n" + addressSender.getDecoratedName() + "\n" + date.toString() + "\n\n"
					+ destinatary.getDecoratedName() + "\n" + addressDestiny.getDecoratedName() + "\n\n";
	}
	
	private String portugueseHeader() {
		return addressDestiny.getDecoratedName() + ", " + date.toString() + "\n\n" + destinatary.getDecoratedName() + "\n\n";
	}
	
	public CommercialHeader(String structure){
		_structure = structure;
	}
	
	@Override
	public String getString() {
		if (_structure.equalsIgnoreCase("English"))		return	englishHeader();
		if (_structure.equalsIgnoreCase("Portuguese"))	return	portugueseHeader();
		return englishHeader(); // default
		/*return   date.toString()   +   "\n\n"   +   sender.getDecoratedName()   +   
				"\n"   + addressSender.getDecoratedName()   +   "\n"   +   
				destinatary.getDecoratedName()   + addressDestiny.getDecoratedName()   +   "\n";*/
	}
	
}
