package Lab3;

public class LoveHeader extends Paragraph {

	private String _structure;
	
	private String englishLoveHeader() {
		return "My darling\n";
	}
	
	private String portugueseLoveHeader() {
		return "Meu querido\n";
	}
	
	
	public LoveHeader(String structure) {
		_structure = structure;
	}
	
	@Override
	public String getString() {
		if (_structure.equalsIgnoreCase("English"))		return englishLoveHeader();
		if (_structure.equalsIgnoreCase("Portuguese"))	return portugueseLoveHeader();
		return englishLoveHeader(); // default
	}

}
