package Lab3;

public class LetterBuilder {
	
	private static String _structure;
	
	private static void changeLanguage(String language, Person sender, Person destinatary, Address addressSender, Address addressDestiny, String model) {
		if (language != "") {
			LanguageAbstractFactory languageFactorySender = LanguageFactory.getFactory(sender, addressSender, language);
			languageFactorySender.setPersonDecorated(sender, addressSender, model);
			LanguageAbstractFactory languageFactoryDestinatary = LanguageFactory.getFactory(destinatary, addressDestiny, language);
			languageFactoryDestinatary.setPersonDecorated(destinatary, addressDestiny, model);
		}
	}
	
	private static String getRightStructure(String language, String structure) {
		if (structure.equalsIgnoreCase(""))	return language;
		return structure;
	}

	public static Letter getCommercialLetter(Person sender, Person destinatary, Address addressSender, Address addressDestiny, Date date, String language, String model, String structure) {
		return newCommercialLetter(sender, destinatary, addressSender, addressDestiny, date, language, model, structure);
	}
	
	public static Letter getRomanticLetter(Person sender, Person destinatary, Address addressSender, Address addressDestiny, Date date, String language, String model, String structure) {
		return newRomanticLetter(sender, destinatary, addressSender, addressDestiny, date, language, model, structure);
	}
	
	public static Letter getAdvertisingLetter(Person sender, Person destinatary, Address addressSender, Address addressDestiny, Date date, String language, String model, String structure) {
		return newAdvertisingLetter(sender, destinatary, addressSender, addressDestiny, date, language, model, structure);
	}

	private static Letter newCommercialLetter(Person sender, Person destinatary, Address addressSender, Address addressDestiny, Date date, String language, String model, String structure) {
		changeLanguage(language, sender, destinatary, addressSender, addressDestiny, model); 
		
		Letter letter = new Letter(sender, destinatary, addressSender, addressDestiny, date);
		
		_structure = getRightStructure(language, structure);
		
		letter.addParagraph(new CommercialHeader(_structure));
		letter.addParagraph(new CommercialBody());
		letter.addParagraph(new CommercialConclusion(_structure));
		letter.addParagraph(new CommercialSignature(_structure));
		
		return letter;
	}
	
	private static Letter newRomanticLetter(Person sender, Person destinatary, Address addressSender, Address addressDestiny, Date date, String language, String model, String structure) {
		changeLanguage(language, sender, destinatary, addressSender, addressDestiny, model);
		
		Letter letter = new Letter(sender, destinatary, addressSender, addressDestiny, date);
		
		_structure = getRightStructure(language, structure);
		
		letter.addParagraph(new LoveHeader(_structure));
		letter.addParagraph(new LoveBody());
		letter.addParagraph(new LoveConclusion(_structure));
		
		return letter;
	}
	
	private static Letter newAdvertisingLetter(Person sender, Person destinatary, Address addressSender, Address addressDestiny, Date date, String language, String model, String structure) {
		changeLanguage(language, sender, destinatary, addressSender, addressDestiny, model);
		
		Letter letter = new Letter(sender, destinatary, addressSender, addressDestiny, date);
		
		_structure = getRightStructure(language, structure);
		
		letter.addParagraph(new CommercialHeader(_structure));
		letter.addParagraph(new CommercialBody());
		letter.addParagraph(new AdvertisingConclusion(_structure));
		
		return letter;
	}
	
}
