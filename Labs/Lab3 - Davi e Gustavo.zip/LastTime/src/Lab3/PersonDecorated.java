package Lab3;

public interface PersonDecorated {
	
	public String getName();
	public String getAddress();
	public String getPhoneNumber();
	
}
