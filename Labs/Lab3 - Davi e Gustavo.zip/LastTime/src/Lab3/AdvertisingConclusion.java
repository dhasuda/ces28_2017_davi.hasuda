package Lab3;

public class AdvertisingConclusion extends Paragraph {

	private String _structure;
	
	private String englishAdvertisingConclusion() {
		return "             Have a nice week\n";
	}
	
	private String portugueseAdvertisingConclusion() {
		return "             Tenha uma boa semana\n";
	}
	
	public AdvertisingConclusion (String structure) {
		_structure = structure;
	}
	
	@Override
	public String getString() {
		if (_structure.equalsIgnoreCase("English"))		return	englishAdvertisingConclusion();
		if (_structure.equalsIgnoreCase("Portuguese"))	return	portugueseAdvertisingConclusion();
		return	englishAdvertisingConclusion(); // default
	}
}
