package Lab3;
public class LoveConclusion extends Paragraph {

	private String _structure;
	
	private String englishLoveConclusion() {
		return "\n\n                 With all my love\n";
	}
	
	private String portugueseLoveConclusion() {
		return "\n\n                 Com todo o meu amor\n";
	}
	
	public LoveConclusion (String structure) {
		_structure = structure;
	}
	
	@Override
	public String getString() {
		if (_structure.equalsIgnoreCase("English"))		return	englishLoveConclusion();
		if (_structure.equalsIgnoreCase("Portuguese"))	return	portugueseLoveConclusion();
		return	englishLoveConclusion();
	}
	
}
