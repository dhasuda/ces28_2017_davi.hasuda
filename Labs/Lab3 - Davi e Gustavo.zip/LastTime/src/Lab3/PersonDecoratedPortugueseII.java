package Lab3;

public class PersonDecoratedPortugueseII implements PersonDecorated {

	private String _decoratedName;
	private String _decoratedPhoneNumber;
	private String _decoratedAddress;
	
	private String decorateName(String name) {
		return "Sr. " + name;
	}
	
	private String decoratePhoneNumber(String phoneNumber) {
		return "DDI: +55 Tel: " + phoneNumber;
	}
	
	private String decorateAddress(String address){
		return "Rua " + address;
	}
	
	
	public PersonDecoratedPortugueseII(Person person, Address address) {
		_decoratedName = decorateName(person.getName());
		_decoratedPhoneNumber = decoratePhoneNumber(person.getPhone());
		_decoratedAddress = decorateAddress(address.getName());
	}
	
	public String getName() {
		return _decoratedName;
	}
	
	public String getAddress() {
		return _decoratedAddress;
	}
	
	public String getPhoneNumber() {
		return _decoratedPhoneNumber;
	}
}
