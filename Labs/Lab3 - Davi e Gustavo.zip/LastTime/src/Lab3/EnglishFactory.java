package Lab3;

import java.util.HashMap;
import java.util.Map;

public class EnglishFactory implements LanguageAbstractFactory {

	private Map<String, PersonDecorated> _dictionary = new HashMap<String, PersonDecorated>();
	
	private String _name;
	private String _phoneNumber;
	private String _address;
	
	public EnglishFactory(Person person, Address address) {
		_dictionary.put("I", new PersonDecoratedEnglishI(person, address));
	}
	
	public void setPersonDecorated(Person person, Address address, String model){
		try {
			_name = _dictionary.get(model).getName();
			_phoneNumber = _dictionary.get(model).getPhoneNumber();
			_address = _dictionary.get(model).getAddress();
		} catch (Exception e) {
			_name = _dictionary.get("I").getName();
			_phoneNumber = _dictionary.get("I").getPhoneNumber();
			_address = _dictionary.get("I").getAddress();
		}
		
		person.setDecoratedName(_name);
		person.setDecoratedPhoneNumber(_phoneNumber);
		address.setDecoratedName(_address);
	}

}
