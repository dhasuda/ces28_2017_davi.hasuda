package Lab3;

public class LoveBody extends Paragraph {

	@Override
	public String getString() {
		return "I love you \n";
	}

}
