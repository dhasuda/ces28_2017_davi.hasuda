package Lab3;

public interface LanguageAbstractFactory {
	public abstract void setPersonDecorated(Person person, Address address, String model);
}
