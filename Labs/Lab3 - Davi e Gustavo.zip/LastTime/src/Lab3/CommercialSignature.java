package Lab3;


public class CommercialSignature extends Paragraph {

	private String _structure;
	
	private String englishSignature() {
		return "\n\n__________________\n " + sender.getDecoratedPhone() +
				 sender.getDecoratedName() + "\n" +
				 "\n                                    email:"   +   sender.getEmail();
	}
	
	private String portugueseSignature() {
		return "\n\n__________________\n " +
				 sender.getDecoratedName() + "\n" + sender.getDecoratedPhone() +
				 "\n" + "email:"   +   sender.getEmail();
	}
	
	
	public CommercialSignature(String structure) {
		_structure = structure;
	}
	
	
	
	@Override
	public String getString() {
		if (_structure.equalsIgnoreCase("English"))		return	englishSignature();
		if (_structure.equalsIgnoreCase("Portuguese"))	return	portugueseSignature();
		return englishSignature(); // default
	}

}
