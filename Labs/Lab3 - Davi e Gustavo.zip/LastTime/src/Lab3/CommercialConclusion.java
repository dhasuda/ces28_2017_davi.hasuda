package Lab3;


public class CommercialConclusion extends Paragraph {
	
	private String _structure;
	
	private String englishConclusion() {
		return "\nSincerely,\n";
	}
	
	private String portugueseConclusion() {
		return "\nAtenciosamente\n";
	}
	
	public CommercialConclusion(String structure) {
		_structure = structure;
	}
	
	@Override
	public String getString() {
		if (_structure.equalsIgnoreCase("English"))		return	englishConclusion();
		if (_structure.equalsIgnoreCase("Portuguese")) 	return	portugueseConclusion();
		return englishConclusion(); // default
	}

}
