package BDProduto;

public interface Compravel {
	public String getNome();
	public double getPreco();
}
