package BDCliente;

public interface VerificadorCPF {
	public Boolean CPFValido(String cpf);
}
