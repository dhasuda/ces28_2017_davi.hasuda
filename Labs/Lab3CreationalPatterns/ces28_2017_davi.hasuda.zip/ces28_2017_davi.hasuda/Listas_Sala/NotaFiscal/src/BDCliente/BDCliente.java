package BDCliente;

public interface BDCliente {
	
	public Cliente getCliente(String cpf) throws NullPointerException;
	
	//public Boolean CPFValido(String cpf);
	
}
