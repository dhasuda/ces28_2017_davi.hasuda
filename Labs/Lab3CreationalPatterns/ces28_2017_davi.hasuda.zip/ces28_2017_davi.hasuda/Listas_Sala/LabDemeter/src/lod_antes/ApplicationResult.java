package lod_antes;

public class ApplicationResult {

	public boolean isSuccess() {
		// TODO Auto-generated method stub
		return false;
	}

	public void setSuccess(boolean b) {
		// TODO Auto-generated method stub
		
	}

	public void setMessage(String string) {
		// TODO Auto-generated method stub
		
	}

	public String getMessage() {
		// TODO Auto-generated method stub
		return null;
	}

}
