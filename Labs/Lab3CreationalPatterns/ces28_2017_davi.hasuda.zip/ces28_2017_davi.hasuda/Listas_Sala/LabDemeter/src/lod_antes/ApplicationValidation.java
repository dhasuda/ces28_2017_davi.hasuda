package lod_antes;

public class ApplicationValidation {

	public ApplicationResult validate(Applicant applicant) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public ApplicationDao getApplicationDao() {
		// TODO Auto-generated method stub
		return null;
	}


}
