package lod_antes;

public class ApplicationDao {

	public ApplicationResult persist(Applicant applicant) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
