package ref3;

public class ApplicationDao {

	public boolean persist(Applicant applicant) {
		// TODO Auto-generated method stub
		return false;
	}
	
}
