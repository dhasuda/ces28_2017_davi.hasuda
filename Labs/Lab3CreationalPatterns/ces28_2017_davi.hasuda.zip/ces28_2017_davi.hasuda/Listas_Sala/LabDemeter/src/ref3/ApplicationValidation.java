package ref3;

public class ApplicationValidation {

	public boolean validate(Applicant applicant) {
		// TODO Auto-generated method stub
		return false;
	}

}
