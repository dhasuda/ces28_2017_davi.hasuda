package labmock;

public interface IVirtualProcess {
	public IVirtualProcess getVirtualProcess();
}
