package Depois;

public class SavingsAccount extends BankAccount {
	public void AddInterest(double amount) {};
}
