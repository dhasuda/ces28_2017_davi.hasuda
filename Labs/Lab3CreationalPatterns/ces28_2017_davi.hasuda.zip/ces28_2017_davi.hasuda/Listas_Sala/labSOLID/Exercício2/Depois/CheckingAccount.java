package Depois;

public class CheckingAccount extends BankAccount {
	public void Transfer(double amount, BankAccount fromAccount, BankAccount toAccount) {};
}
