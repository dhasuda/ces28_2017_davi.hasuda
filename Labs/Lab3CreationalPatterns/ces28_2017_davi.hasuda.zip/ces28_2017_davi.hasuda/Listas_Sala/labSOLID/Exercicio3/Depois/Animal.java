package Depois;

public abstract interface Animal {
	public abstract void feed();
}
