package Depois;

public abstract interface PuffyAnimal {
	public abstract void groom();
}
