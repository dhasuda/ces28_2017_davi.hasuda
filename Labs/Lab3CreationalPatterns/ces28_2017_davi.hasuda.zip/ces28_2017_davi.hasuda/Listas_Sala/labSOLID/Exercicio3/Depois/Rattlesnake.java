package Depois;

public class Rattlesnake implements Animal {
	public void feed() {
		// do something
	}
}

