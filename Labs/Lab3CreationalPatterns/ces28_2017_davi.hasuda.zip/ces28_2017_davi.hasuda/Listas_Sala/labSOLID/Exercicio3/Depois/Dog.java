package Depois;

public class Dog implements PuffyAnimal, Animal {
	public void feed() {
		// do something
	}
	public void groom() {
		// do something
	}
}
