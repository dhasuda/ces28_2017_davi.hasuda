package Antes;

public abstract class Animal {
	public abstract void feed();
	public abstract void groom();
}

/*
 * O ISP se assemelha bastante ao pricípio expert dos padrões GRASP.
 * O código acima não obede ao ISP
 * */