package Antes;

public class Dog extends Animal {
	public void feed() {
		// do something
	}
	public void groom() {
		// do something
	}
}
