package Q4;

public interface Sensor {
	public double getVelocidade();
	public boolean isCruzamento();
}
