package DrinkPackage;

class Ingredient4 extends Ingredient {
	public Ingredient4() {
		this._price = 10;
	}
}
