package DrinkPackage;

class Ingredient3 extends Ingredient {
	public Ingredient3() {
		this._price = 10;
	}
}
