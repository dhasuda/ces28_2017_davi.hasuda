package Lab3;

public class AdvertisingConclusion extends Paragraph {

	@Override
	public String getString() {
		return "             Have a nice week\n";
	}
}
