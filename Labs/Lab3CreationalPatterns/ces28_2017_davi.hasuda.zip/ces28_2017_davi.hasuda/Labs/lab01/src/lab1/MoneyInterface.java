package lab1;

public interface MoneyInterface {
	MoneyInterface add(Money money);
}
