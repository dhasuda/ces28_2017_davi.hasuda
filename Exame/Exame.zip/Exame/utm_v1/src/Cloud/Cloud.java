package Cloud;

import java.util.HashSet;
import java.util.Observable;
import java.util.Observer;
import Drone.Drone;
import Drone.SelfInfo;
import UTM_CTR.SituationalMap;
import UTM_CTR.UTM;

public class Cloud implements Observer {
	
	private static Cloud cloud =  new Cloud();
	private static AllInfo allInfo;
	private static HashSet<Drone> dronesList = new HashSet<Drone>();
	
	private Cloud() {
		allInfo = new AllInfo();
	}
	
	public static Cloud getCloud() {
		return cloud;
	}
	
	
	public void update(Observable o, Object arg) {
		//System.out.println("Updating all infos in cloud");
		// Update informações da cloud
		this.updateDronesInfo();
		this.updateUTMInfo();
	}
	
	public void addDrone(Drone newDrone) {
		dronesList.add(newDrone);
	}

	public AllInfo getAllInfo() {
		return allInfo;
	}
	
	public void updateDronesInfo() {
		//System.out.println("Updating Drones Info");
		HashSet<SelfInfo> newInfo = new HashSet<SelfInfo>();
		for (Drone d : dronesList) {
			newInfo.add(d.getSelfInfo());
		}
		allInfo.setDronesInfo(newInfo);
	}
	public void updateUTMInfo() {
		//System.out.println("Updating UTM Info");
		SituationalMap newInfo = UTM.getUTM().getInfo();
		allInfo.setSaInfo(newInfo);
	}
	public HashSet<Drone> getDroneList() {
		return Cloud.dronesList;
	}

}
