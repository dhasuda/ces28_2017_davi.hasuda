package UTM_CTR;

import java.util.Observable;

import Cloud.Cloud;

public class UTM extends Observable {
	private static UTM utm = new UTM();
	private SituationalMap map;
	
	
	private UTM() {
		this.map = new SituationalMap();
		this.addObserver(Cloud.getCloud());
	}
	public static UTM getUTM() {
		return utm;
	}
	
	public SituationalMap getInfo() {
		return this.map;
	}
	
	public void setMap(SituationalMap newMap) {
		this.map = newMap;
		super.setChanged();
		//this.updateCloud();
	}
	
	public void updateCloud() {
		// Não sei implementar uma thread que verifica a cada 20 segundos, então vou deixar esta função aqui
		super.notifyObservers();
	}
	
}
