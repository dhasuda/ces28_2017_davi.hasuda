package UTM_CTR;

/*
 * Same as SAInfo
 */
public class SituationalMap {
	public SituationalMap() {}
	public boolean hasObstacle() {
		// Implementar alguma lógica para identificar obstáculos
		return false;
	}
}
