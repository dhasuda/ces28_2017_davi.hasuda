package tests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import Cloud.AllInfo;
import Cloud.Cloud;
import Drone.Drone;
import Drone.GCS;


/*
 * Presenter Tests
 */
public class PresenterTests {
	private Cloud cloud;
	
	@Before
	public void setUp() {
		cloud  = Cloud.getCloud();
	}
	
	
	@Test
	public void testCloudGetAllInfo() {
		AllInfo info = cloud.getAllInfo();
		assertNotNull(info);
	}
	
	@Test
	public void testAddDroneToCloudThroughGCS() {
		//Drone d = new Drone();
		GCS gcs1 = new GCS("name");
		assertEquals(cloud.getDroneList().size(), 1);
		GCS gcs2 = new GCS("name2");
		assertEquals(cloud.getDroneList().size(), 2);
		
	}
	
	@Test
	public void testCloudGetUTMInfo() {
		AllInfo info = cloud.getAllInfo();
		assertNotNull(info);
	}
	
}
