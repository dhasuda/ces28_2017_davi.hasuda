package tests;


import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import Drone.Drone;
import Drone.GCS;

/*
 * View tests
 */
public class ViewTests {
	private GCS gcs = new GCS("gcs");
	private GCS gcsSpy = Mockito.spy(gcs);
	private Drone drone;
	private Drone droneSpy;
//	Environment environment;
	
	@Before
	public void setUp() {
		drone = gcs.getDrone();
		droneSpy = Mockito.spy(drone);
	}

	@Test
	public void testDroneControlByGCS() {
		/*
		 * When it's raining
		 */
		Mockito.doReturn(true).when(gcsSpy).isRaining();
		gcsSpy.controlDroneToPosition(0.0, 0.0, 0.0);
		Mockito.verify(gcsSpy, Mockito.times(0)).droneToPosition(0.0, 0.0, 0.0);
		
		/*
		 * When it's not raining
		 */
		Mockito.doReturn(false).when(gcsSpy).isRaining();
		gcsSpy.controlDroneToPosition(0.0, 0.0, 0.0);
		Mockito.verify(gcsSpy, Mockito.times(1)).droneToPosition(0.0, 0.0, 0.0);
		
	}
	
	@Test
	public void testDronePositionControlByDrone() {
		droneSpy.goToNewPosition(0.0, 0.0, 0.0);
		Mockito.verify(droneSpy, Mockito.times(1)).goToNewPosition(0.0, 0.0, 0.0);
	}
	
	@Test
	public void testChangeDronePosition() {
		Drone d = new Drone();
		assertFalse(d.hasChanged());
		d.goToNewPosition(0.0, 0.0, 0.0);
		assertTrue(d.hasChanged());
	}

}
