package tests;

import static org.junit.Assert.*;

import org.junit.Test;

import Cloud.Cloud;
import Drone.GCS;
import UTM_CTR.UTM;

public class initializations {

	@Test
	public void testCloudSingleton() {
		Cloud cloud1 = Cloud.getCloud();
		Cloud cloud2 = Cloud.getCloud();
		assertNotNull(cloud1);
		assertTrue(cloud1 == cloud2);
	}
	
	@Test
	public void testUTMSingleton() {
		UTM utm1 = UTM.getUTM();
		UTM utm2 = UTM.getUTM();
		assertNotNull(utm1);
		assertTrue(utm1 == utm2);
	}
	
	@Test
	public void testCGSConstructor() {
		GCS gcs = new GCS("gcs1");
		assertNotNull(gcs);
		assertNotNull(gcs.getDrone());
		// Here we alse tested the drone Constructor
	}

}
