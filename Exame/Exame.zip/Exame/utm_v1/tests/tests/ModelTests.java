package tests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import UTM_CTR.SituationalMap;
import UTM_CTR.UTM;

/*
 * Model is the UTM
 */
public class ModelTests {
	UTM utm = UTM.getUTM();
	
	@Before
	public void setUp() {
	}
	
	@Test
	public void testSingleton() {
		UTM utm2 = UTM.getUTM();
		assertEquals(utm, utm2);
	}
	
	@Test
	public void testAddMap() {
		assertFalse(utm.hasChanged());
		SituationalMap map = new SituationalMap();
		utm.setMap(map);
		assertTrue(utm.hasChanged());
	}

}
