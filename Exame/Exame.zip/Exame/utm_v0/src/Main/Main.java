package Main;

import Cloud.Cloud;
import Drone.GCS;
import UTM_CTR.UTM;

public class Main {
	public static void main(String [] args) {
		
		/*
		 * Check if all drones respond to the cgs as expected
		 */
		GCS gcs1 = new GCS("gcs1");
		GCS gcs2 = new GCS("gcs2");
		GCS gcs3 = new GCS("gcs3");
		
		// It may be raining, so the drones won't move (it is implemented as a rand inside EnvironmentImplementation)
		gcs1.controlDroneToPosition(0.0, 0.0, 0.0);
		gcs2.controlDroneToPosition(1.0, 1.0, 1.0);
		gcs3.controlDroneToPosition(-1.0, -1.0, -1.0);
		System.out.println("----------");
		
		/*
		 * Check the data updates
		 */
		Cloud cloud = Cloud.getCloud(); 
		cloud.updateDronesInfo();
		cloud.updateUTMInfo();
		System.out.println("----------");
		cloud.update(null, null);
		System.out.println("----------");
		
		/*
		 * Check if the notify in observer/observable relationship works 
		 */
		UTM utm = UTM.getUTM();
		utm.setMap(null); // To call setChanged()
		utm.updateCloud();
		System.out.println("----------");
		// This one only works if it's not raining for gcs1
		gcs1.getDrone().updateCloud();
	}
}
