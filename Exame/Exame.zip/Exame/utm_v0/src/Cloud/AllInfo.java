package Cloud;

import java.util.HashSet;

import Drone.SelfInfo;
import UTM_CTR.SituationalMap;

public class AllInfo {
	private HashSet<SelfInfo> dronesInfo;
	private SituationalMap saInfo;
	
	public HashSet<SelfInfo> getDronesInfo() {
		return dronesInfo;
	}
	public SituationalMap getSaInfo() {
		return saInfo;
	}
	public void setDronesInfo(HashSet<SelfInfo> newInfo) {
		this.dronesInfo = newInfo;
	}
	public void setSaInfo(SituationalMap newInfo) {
		this.saInfo = newInfo;
	}
}
