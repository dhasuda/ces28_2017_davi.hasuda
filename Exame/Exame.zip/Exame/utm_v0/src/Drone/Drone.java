package Drone;

import java.util.Observable;
import Cloud.Cloud;

public class Drone extends Observable {

	private SelfInfo selfInfo;
	
	public Drone() {
		Cloud.getCloud().addDrone(this);
		this.addObserver(Cloud.getCloud());
	} // Package private
	
	private void avoidObstacles() {
		// Something that recognizes and avoids obstacles
	}
	
	// Package private function
	void goToNewPosition(double x, double y, double z) {
		avoidObstacles();
		// Go to desired position
		System.out.println("Drone going to position ("+x+"; "+y+"; "+z+")" ); 
		this.updateSelfInfo();
		super.setChanged();
		//this.updateCloud();
	}
	
	public void updateCloud() {
		// Não sei criar threads para atualizar a CLOUD a cada 10 segundos, então estou deixando esta função pronta aqui para ser colocada na thread
		super.notifyObservers();
	}
	
	public void updateSelfInfo() {
		// Lógica que o drone é capaz de saber sua posição
	}
	
	public SelfInfo getSelfInfo() {
		return this.selfInfo;
	}
}
