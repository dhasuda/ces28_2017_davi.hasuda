package Drone;

public interface SelfInfo {
	public double getXPosition();
	public double getYPosition();
	public double getZPosition();
}
