package Drone;

public class EnvironmentImplementation implements Environment {

	@Override
	public boolean isRaining() {
		if(Math.random() < 0.5) {
		    return false;
		}
		return true;
	}

}
