package Drone;

import Cloud.Cloud;

public class GCS {
	private Environment environment;
	private Drone drone;
	private Cloud cloud;
	private String name;
	
	public GCS(String name) {
		// Inicializar environment
		this.environment = new EnvironmentImplementation(); // Apenas para poder ser utilizado na main
		this.name = name;
		this.drone = new Drone();
		this.cloud = Cloud.getCloud();
		drone.addObserver(cloud);
	}
	
	public void controlDroneToPosition(double x, double y, double z) {
		// Uses the environment data to make modifications to x, y, z
		System.out.println(this.name + " is controlling its drone");
		if (environment.isRaining()) {
			System.out.println("Can't control drone because it's raining");
		} else {
			this.drone.goToNewPosition(x, y, z);
		}
	}
	
	public Drone getDrone() {
		return this.drone;
	}
}
