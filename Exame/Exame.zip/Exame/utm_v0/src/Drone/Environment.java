package Drone;

public interface Environment {
	public boolean isRaining();
	// Métodos que fornecem informações sobre as condições do local próximos ao GCS
}
